return {
  "zk-org/zk-nvim",
  lazy = false,
  config = function()
    require("zk").setup({
      picker = "telescope", -- Use Telescope for picking notes
      lsp = {
        config = {
          cmd = { "zk", "lsp" },
          name = "zk",
        },
        auto_attach = {
          enabled = true,
          filetypes = { "markdown" },
        },
      },
    })
    local opts = { noremap = true, silent = true }

    -- Create a new note after asking for its title.
    vim.api.nvim_set_keymap("n", "<leader>zn", "<Cmd>ZkNew { title = vim.fn.input('Title: ') }<CR>", opts)

    -- Open notes.
    vim.api.nvim_set_keymap("n", "<leader>zo", "<Cmd>ZkNotes { sort = { 'modified' } }<CR>", opts)
    -- Open notes associated with the selected tags.
    vim.api.nvim_set_keymap("n", "<leader>zt", "<Cmd>ZkTags<CR>", opts)
    -- Search for the notes matching a given query.
    vim.api.nvim_set_keymap(
      "n",
      "<leader>zf",
      "<Cmd>ZkNotes { sort = { 'modified' }, match = { vim.fn.input('Search: ') } }<CR>",
      opts
    )
    -- Search for the notes matching the current visual selection.
    vim.api.nvim_set_keymap("v", "<leader>zf", ":'<,'>ZkMatch<CR>", opts)
    -- Search for oprhaned notes
    vim.api.nvim_set_keymap("n", "<leader>zp", ":ZkOrphans<CR>", opts)
    -- Search for recent notes
    vim.api.nvim_set_keymap("n", "<leader>zr", ":ZkRecents<CR>", opts)
    -- Daily journal
    vim.api.nvim_set_keymap("n", "<leader>zj", "<Cmd>ZkNew { dir = 'daily_journal', group = 'daily' }<CR>", opts)

    -- ZK Link from selection
    vim.api.nvim_set_keymap("n", "<leader>zm", ":ZkInsertLink<CR>", { noremap = true, silent = true })
    vim.api.nvim_set_keymap("v", "<leader>zm", ":ZkInsertLinkAtSelection<CR>", { noremap = true, silent = true })
    local zk = require("zk")
    local commands = require("zk.commands")

    local function make_edit_fn(defaults, picker_options)
      return function(options)
        options = vim.tbl_extend("force", defaults, options or {})
        zk.edit(options, picker_options)
      end
    end

    commands.add("ZkOrphans", make_edit_fn({ orphan = true }, { title = "Zk Orphans" }))
    commands.add("ZkRecents", make_edit_fn({ createdAfter = "2 weeks ago" }, { title = "Zk Recents" }))
  end,
  dependencies = { -- Make sure these are installed
    "nvim-telescope/telescope.nvim",
  },
}
