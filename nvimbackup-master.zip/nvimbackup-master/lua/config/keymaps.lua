-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here

-- ~/.config/nvim/lua/config/keymaps.lua

local map = vim.keymap.set

-- Keybindings for molten-nvim
map("n", "<leader>mi", ":MoltenInit<CR>", { silent = true, desc = "Initialize the plugin" })
map("n", "<leader>me", ":MoltenEvaluateOperator<CR>", { silent = true, desc = "Run operator selection" })
map("n", "<leader>mrl", ":MoltenEvaluateLine<CR>", { silent = true, desc = "Evaluate line" })
map("n", "<leader>mrr", ":MoltenReevaluateCell<CR>", { silent = true, desc = "Re-evaluate cell" })
map("v", "<leader>mrv", ":<C-u>MoltenEvaluateVisual<CR>gv", { silent = true, desc = "Evaluate visual selection" })
map("n", "<leader>md", ":MoltenDelete<CR>", { silent = true, desc = "Molten delete cell" })
map("n", "<leader>mh", ":MoltenHideOutput<CR>", { silent = true, desc = "Hide output" })
map("n", "<leader>mc", ":noautocmd MoltenEnterOutput<CR>", { silent = true, desc = "Show/enter output" })
-- Initialize Molten for Python (with virtual env detection)
map("n", "<leader>ip", function()
  local venv = os.getenv("VIRTUAL_ENV") or os.getenv("CONDA_PREFIX")
  if venv ~= nil then
    -- in the form of /home/benlubas/.virtualenvs/VENV_NAME
    venv = string.match(venv, "/.+/(.+)")
    vim.cmd(("MoltenInit %s"):format(venv))
  else
    vim.cmd("MoltenInit python3")
  end
end, { desc = "Initialize Molten for python3", silent = true })

-- You can add other keybindings for different plugins or general Neovim here
